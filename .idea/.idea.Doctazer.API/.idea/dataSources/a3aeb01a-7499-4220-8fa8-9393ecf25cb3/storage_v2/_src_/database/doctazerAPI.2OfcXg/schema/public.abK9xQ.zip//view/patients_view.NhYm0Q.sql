create view patients_view as
  SELECT patients.id,
         patients.user_id,
         patients.firstname,
         patients.lastname,
         patients.dob,
         patients.gender,
         patients.phone,
         anu."Email",
         a.address,
         a.city_id,
         a.latitude,
         a.long,
         c.az AS c_az,
         c.en AS c_en,
         c.ru AS c_ru
  FROM (((patients
      LEFT JOIN "AspNetUsers" anu ON ((patients.user_id = anu."Id")))
      LEFT JOIN addresses a ON ((anu."Id" = a.user_id)))
      LEFT JOIN cities c ON ((a.city_id = c.id)));

alter table patients_view
  owner to postgres;

