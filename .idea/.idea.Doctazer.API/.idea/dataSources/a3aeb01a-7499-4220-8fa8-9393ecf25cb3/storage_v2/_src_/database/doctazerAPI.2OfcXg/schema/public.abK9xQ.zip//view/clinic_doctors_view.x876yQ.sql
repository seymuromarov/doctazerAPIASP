create view clinic_doctors_view as
  SELECT clinic_doctors.id,
         clinic_doctors.doctor_id,
         clinic_doctors.clinic_id,
         clinic_doctors.created_at,
         c.name,
         concat(d.firstname, ' ', d.lastname) AS doctor_name
  FROM ((clinic_doctors
      LEFT JOIN clinics c ON ((clinic_doctors.clinic_id = c.id)))
      LEFT JOIN doctors d ON ((clinic_doctors.doctor_id = d.id)));

alter table clinic_doctors_view
  owner to postgres;

