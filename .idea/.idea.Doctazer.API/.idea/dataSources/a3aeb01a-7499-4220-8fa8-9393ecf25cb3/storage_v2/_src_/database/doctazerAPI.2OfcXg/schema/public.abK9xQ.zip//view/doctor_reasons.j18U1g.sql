create view doctor_reasons as
  SELECT d.id,
         d.user_id,
         d.firstname,
         d.lastname,
         d.phone,
         d.speciality_id,
         d.about,
         d.from_availabilities,
         d.to_availabilities,
         reasons.id AS reason_id,
         reasons.name
  FROM (reasons
      LEFT JOIN doctors d ON ((reasons.doctor_id = d.id)));

alter table doctor_reasons
  owner to postgres;

