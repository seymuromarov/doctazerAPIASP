create view doctor_appointments as
  SELECT appointments.id,
         appointments.slot_id,
         appointments.date,
         appointments."time",
         appointments.patient_id,
         appointments.doctor_id,
         appointments.clinic_id,
         c.name,
         concat(d.firstname, ' ', d.lastname) AS doctor_name,
         concat(p.firstname, ' ', p.lastname) AS patient_name
  FROM (((appointments
      LEFT JOIN clinics c ON ((appointments.clinic_id = c.id)))
      LEFT JOIN doctors d ON ((appointments.doctor_id = d.id)))
      LEFT JOIN patients p ON ((appointments.patient_id = p.id)));

alter table doctor_appointments
  owner to postgres;

