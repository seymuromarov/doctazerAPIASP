create view clinics_view as
  SELECT clinics.id,
         clinics.name,
         clinics.phone,
         clinics.about,
         clinics.user_id,
         a.address,
         a.city_id,
         a.latitude,
         a.long,
         c.az AS c_az,
         c.en AS c_en,
         c.ru AS c_ru
  FROM (((clinics
      LEFT JOIN "AspNetUsers" anu ON ((clinics.user_id = anu."Id")))
      LEFT JOIN addresses a ON ((anu."Id" = a.user_id)))
      LEFT JOIN cities c ON ((a.city_id = c.id)));

alter table clinics_view
  owner to postgres;

