create view doctors_view as
  SELECT doctors.id,
         doctors.user_id,
         doctors.firstname,
         doctors.lastname,
         doctors.phone,
         doctors.speciality_id,
         doctors.about,
         doctors.from_availabilities,
         doctors.to_availabilities,
         anu."Id",
         anu."UserName",
         anu."NormalizedUserName",
         anu."Email",
         s.az AS speciality_az,
         s.en AS speciality_en,
         s.ru AS speciality_ru
  FROM (((doctors
      LEFT JOIN "AspNetUsers" anu ON ((doctors.user_id = anu."Id")))
      LEFT JOIN addresses a ON ((anu."Id" = a.user_id)))
      LEFT JOIN specialities s ON ((doctors.speciality_id = s.id)));

alter table doctors_view
  owner to postgres;

