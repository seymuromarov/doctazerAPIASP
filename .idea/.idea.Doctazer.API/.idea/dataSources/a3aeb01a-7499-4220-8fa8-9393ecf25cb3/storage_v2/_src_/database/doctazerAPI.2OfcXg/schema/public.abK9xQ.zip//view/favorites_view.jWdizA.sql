create view favorites_view as
  SELECT favorites.id,
         favorites.patient_id,
         favorites.doctor_id,
         concat(d.firstname, ' ', d.lastname) AS doctor_name,
         concat(p.firstname, ' ', p.lastname) AS patient_name
  FROM ((favorites
      LEFT JOIN doctors d ON ((favorites.doctor_id = d.id)))
      LEFT JOIN patients p ON ((favorites.patient_id = p.id)));

alter table favorites_view
  owner to postgres;

