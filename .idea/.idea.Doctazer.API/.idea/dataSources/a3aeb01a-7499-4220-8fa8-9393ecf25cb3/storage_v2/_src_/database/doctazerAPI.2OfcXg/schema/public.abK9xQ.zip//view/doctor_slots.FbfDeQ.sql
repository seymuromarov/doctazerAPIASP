create view doctor_slots as
  SELECT slots.id,
         slots.doctor_id,
         slots.date,
         slots."time",
         slots.filled,
         slots.deleted_at,
         d.firstname,
         d.lastname,
         d.phone
  FROM (slots
      LEFT JOIN doctors d ON ((slots.doctor_id = d.id)));

alter table doctor_slots
  owner to postgres;

